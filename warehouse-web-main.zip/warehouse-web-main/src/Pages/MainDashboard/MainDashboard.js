import React from 'react';
import {Route,Routes} from "react-router-dom";
import Company from "../Sample/Sample";

const MainDashboard = ({}) => {

    return (
        <>
            </>
    )
}
export default MainDashboard
