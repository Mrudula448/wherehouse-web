export default function NotFound(){
    return(
        <h1 style={{marginTop:"100px"}}>Not Found</h1>
    )
}
